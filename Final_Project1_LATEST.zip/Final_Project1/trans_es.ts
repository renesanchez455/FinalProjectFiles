<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="es_ES">
<context>
    <name>Coursedialog</name>
    <message>
        <location filename="coursedialog.ui" line="26"/>
        <source>Coursedialog</source>
        <translation type="unfinished">diálogo del curso</translation>
    </message>
    <message>
        <location filename="coursedialog.ui" line="47"/>
        <source>Register</source>
        <translation type="unfinished">Registrarse</translation>
    </message>
    <message>
        <location filename="coursedialog.ui" line="60"/>
        <source>Cancel</source>
        <translation type="unfinished">cancelar</translation>
    </message>
    <message>
        <location filename="coursedialog.ui" line="76"/>
        <source>Description</source>
        <translation type="unfinished">descripción</translation>
    </message>
    <message>
        <location filename="coursedialog.ui" line="118"/>
        <source>Credits</source>
        <translation type="unfinished">creditos</translation>
    </message>
    <message>
        <location filename="coursedialog.ui" line="152"/>
        <source>Course ID</source>
        <translation type="unfinished">identificaion del curso</translation>
    </message>
    <message>
        <location filename="coursedialog.ui" line="170"/>
        <source>Course Name</source>
        <translation type="unfinished">Nombre del curso</translation>
    </message>
    <message>
        <location filename="coursedialog.ui" line="216"/>
        <source>           Sequence Management System - Course Information</source>
        <translation type="unfinished">Sistema de gestión de secuencias - Información del curso</translation>
    </message>
</context>
<context>
    <name>Lecturerdialog</name>
    <message>
        <location filename="lecturerdialog.ui" line="26"/>
        <source>Lecturerdialog</source>
        <translation type="unfinished">Diálogo del profesor</translation>
    </message>
    <message>
        <location filename="lecturerdialog.ui" line="46"/>
        <source>First Name</source>
        <translation type="unfinished">primer nombre</translation>
    </message>
    <message>
        <location filename="lecturerdialog.ui" line="80"/>
        <source>Last Name</source>
        <translation type="unfinished">apellido</translation>
    </message>
    <message>
        <location filename="lecturerdialog.ui" line="114"/>
        <source>Password</source>
        <translation type="unfinished">contraseña</translation>
    </message>
    <message>
        <location filename="lecturerdialog.ui" line="145"/>
        <source>Email</source>
        <translation type="unfinished">correo electrónico</translation>
    </message>
    <message>
        <location filename="lecturerdialog.ui" line="179"/>
        <source>Phone</source>
        <translation type="unfinished">teléfono</translation>
    </message>
    <message>
        <location filename="lecturerdialog.ui" line="213"/>
        <source>Birth Date</source>
        <translation type="unfinished">fecha de nacimiento</translation>
    </message>
    <message>
        <location filename="lecturerdialog.ui" line="247"/>
        <source>Gender</source>
        <translation type="unfinished">género</translation>
    </message>
    <message>
        <location filename="lecturerdialog.ui" line="288"/>
        <source>Lecturer ID</source>
        <translation type="unfinished">Identificación del profesor</translation>
    </message>
    <message>
        <location filename="lecturerdialog.ui" line="333"/>
        <source>Ok</source>
        <translation type="unfinished">Ok</translation>
    </message>
    <message>
        <location filename="lecturerdialog.ui" line="343"/>
        <source>Cancel</source>
        <translation type="unfinished">cancelar</translation>
    </message>
    <message>
        <location filename="lecturerdialog.ui" line="380"/>
        <source>           Sequence Management System - Lecturer Information</source>
        <translation type="unfinished">sistema de gestión de secuencias - información del profesor</translation>
    </message>
</context>
<context>
    <name>Lecturerscreen</name>
    <message>
        <location filename="lecturerscreen.ui" line="26"/>
        <source>Lecturerscreen</source>
        <translation type="unfinished">pantalla de conferenciante</translation>
    </message>
    <message>
        <location filename="lecturerscreen.ui" line="64"/>
        <source>Search Student</source>
        <translation type="unfinished">estudiante de búsqueda</translation>
    </message>
    <message>
        <location filename="lecturerscreen.ui" line="87"/>
        <source>Generate Report</source>
        <translation type="unfinished">generar informe</translation>
    </message>
    <message>
        <location filename="lecturerscreen.ui" line="107"/>
        <source>                                          Sequence Management System - Lecturer Menu</source>
        <translation type="unfinished">sistema de gestión de secuencias - menú del conferenciante</translation>
    </message>
    <message>
        <location filename="lecturerscreen.ui" line="123"/>
        <source>Log Out</source>
        <translation type="unfinished">cerrar sesión</translation>
    </message>
</context>
<context>
    <name>LoginScreen</name>
    <message>
        <location filename="loginscreen.ui" line="26"/>
        <source>LoginScreen</source>
        <translation type="unfinished">pantalla de ingreso al sistema</translation>
    </message>
    <message>
        <location filename="loginscreen.ui" line="66"/>
        <source>Who are You</source>
        <translation type="unfinished">quién eres tú</translation>
    </message>
    <message>
        <location filename="loginscreen.ui" line="77"/>
        <source>None</source>
        <translation type="unfinished">ninguna(o)</translation>
    </message>
    <message>
        <location filename="loginscreen.ui" line="82"/>
        <source>Student</source>
        <translation type="unfinished">Alumna(o)</translation>
    </message>
    <message>
        <location filename="loginscreen.ui" line="87"/>
        <source>Lecturer</source>
        <translation type="unfinished">Profesora(o)</translation>
    </message>
    <message>
        <location filename="loginscreen.ui" line="92"/>
        <source>Administrator</source>
        <translation type="unfinished">Administradora(o)</translation>
    </message>
    <message>
        <location filename="loginscreen.ui" line="104"/>
        <source>Username</source>
        <translation type="unfinished">Nombre de usuario</translation>
    </message>
    <message>
        <location filename="loginscreen.ui" line="122"/>
        <source>Password</source>
        <translation type="unfinished">contraseña</translation>
    </message>
    <message>
        <location filename="loginscreen.ui" line="153"/>
        <source>Cancel</source>
        <translation type="unfinished">cancelar</translation>
    </message>
    <message>
        <location filename="loginscreen.ui" line="163"/>
        <source>Login</source>
        <translation>acceso</translation>
    </message>
    <message>
        <location filename="loginscreen.ui" line="200"/>
        <source>                                            Sequence Management System</source>
        <translation type="unfinished">                                                                  sistema de gestión de secuencias</translation>
    </message>
</context>
<context>
    <name>Searchdialog</name>
    <message>
        <location filename="searchdialog.ui" line="26"/>
        <source>Searchdialog</source>
        <translation type="unfinished">diálogo de búsqueda</translation>
    </message>
    <message>
        <location filename="searchdialog.ui" line="97"/>
        <source>Search: </source>
        <translation type="unfinished">Buscar</translation>
    </message>
    <message>
        <location filename="searchdialog.ui" line="112"/>
        <source>None</source>
        <translation type="unfinished">ninguna(o)</translation>
    </message>
    <message>
        <location filename="searchdialog.ui" line="117"/>
        <source>Student</source>
        <translation type="unfinished">Alumna(o)</translation>
    </message>
    <message>
        <location filename="searchdialog.ui" line="122"/>
        <source>Lecturer</source>
        <translation type="unfinished">Profesora(o)</translation>
    </message>
    <message>
        <location filename="searchdialog.ui" line="145"/>
        <source>Search</source>
        <translation type="unfinished">buscar</translation>
    </message>
    <message>
        <location filename="searchdialog.ui" line="155"/>
        <source>Cancel</source>
        <translation type="unfinished">cancelar</translation>
    </message>
    <message>
        <location filename="searchdialog.ui" line="193"/>
        <source>                         Sequence Management System - Search Users</source>
        <translation type="unfinished">Sistema de gestión de secuencias: usuarios de búsqueda</translation>
    </message>
</context>
<context>
    <name>Sequencedialog</name>
    <message>
        <location filename="sequencedialog.ui" line="26"/>
        <source>Sequencedialog</source>
        <translation type="unfinished">diálogo de secuencia</translation>
    </message>
    <message>
        <location filename="sequencedialog.ui" line="47"/>
        <source>Cancel</source>
        <translation type="unfinished">Cancelar</translation>
    </message>
    <message>
        <location filename="sequencedialog.ui" line="57"/>
        <source>Add</source>
        <translation type="unfinished">agregar</translation>
    </message>
    <message>
        <location filename="sequencedialog.ui" line="78"/>
        <source>Syllabus ID</source>
        <translation type="unfinished">identificación del programa de estudios</translation>
    </message>
    <message>
        <location filename="sequencedialog.ui" line="109"/>
        <source>Program</source>
        <translation type="unfinished">
programa</translation>
    </message>
    <message>
        <location filename="sequencedialog.ui" line="133"/>
        <location filename="sequencedialog.ui" line="186"/>
        <location filename="sequencedialog.ui" line="247"/>
        <source>None</source>
        <translation type="unfinished">Ninguna(o)</translation>
    </message>
    <message>
        <location filename="sequencedialog.ui" line="138"/>
        <source>AINT</source>
        <translation type="unfinished">AINT</translation>
    </message>
    <message>
        <location filename="sequencedialog.ui" line="143"/>
        <source>BINT</source>
        <translation type="unfinished">BINT</translation>
    </message>
    <message>
        <location filename="sequencedialog.ui" line="153"/>
        <source>Program Year</source>
        <translation type="unfinished">año del programa</translation>
    </message>
    <message>
        <location filename="sequencedialog.ui" line="162"/>
        <source>Semester</source>
        <translation type="unfinished">semestre</translation>
    </message>
    <message>
        <location filename="sequencedialog.ui" line="191"/>
        <source>1</source>
        <translation type="unfinished">1</translation>
    </message>
    <message>
        <location filename="sequencedialog.ui" line="196"/>
        <source>2</source>
        <translation type="unfinished">2</translation>
    </message>
    <message>
        <location filename="sequencedialog.ui" line="201"/>
        <source>3</source>
        <translation type="unfinished">3</translation>
    </message>
    <message>
        <location filename="sequencedialog.ui" line="206"/>
        <source>4</source>
        <translation type="unfinished">4</translation>
    </message>
    <message>
        <location filename="sequencedialog.ui" line="218"/>
        <source>Course</source>
        <translation type="unfinished">Curso</translation>
    </message>
    <message>
        <location filename="sequencedialog.ui" line="242"/>
        <source>CMPS1134</source>
        <translation type="unfinished">CMPS1134</translation>
    </message>
    <message>
        <location filename="sequencedialog.ui" line="252"/>
        <source>CMPS1131</source>
        <translation type="unfinished">CMPS1131</translation>
    </message>
    <message>
        <location filename="sequencedialog.ui" line="257"/>
        <source>MATH1151</source>
        <translation type="unfinished">MATH1151</translation>
    </message>
    <message>
        <location filename="sequencedialog.ui" line="262"/>
        <source>MATH1201</source>
        <translation type="unfinished">MATH1201</translation>
    </message>
    <message>
        <location filename="sequencedialog.ui" line="267"/>
        <source>ENGL1014</source>
        <translation type="unfinished">ENGL1014</translation>
    </message>
    <message>
        <location filename="sequencedialog.ui" line="272"/>
        <source>CMSP1171</source>
        <translation type="unfinished">CMPS1171</translation>
    </message>
    <message>
        <location filename="sequencedialog.ui" line="277"/>
        <source>CMPS1232</source>
        <translation type="unfinished">CMPS1232</translation>
    </message>
    <message>
        <location filename="sequencedialog.ui" line="282"/>
        <source>CMPS1211</source>
        <translation type="unfinished">CMPS1211</translation>
    </message>
    <message>
        <location filename="sequencedialog.ui" line="287"/>
        <source>PHIL1014</source>
        <translation type="unfinished">PHIL1014</translation>
    </message>
    <message>
        <location filename="sequencedialog.ui" line="292"/>
        <source>MATH1302</source>
        <translation type="unfinished">MATH1302</translation>
    </message>
    <message>
        <location filename="sequencedialog.ui" line="297"/>
        <source>ENG1025</source>
        <translation type="unfinished">ENG1025</translation>
    </message>
    <message>
        <location filename="sequencedialog.ui" line="302"/>
        <source>PHYS1015</source>
        <translation type="unfinished">PHYS1015</translation>
    </message>
    <message>
        <location filename="sequencedialog.ui" line="307"/>
        <source>PHYS1015L</source>
        <translation type="unfinished">PHYS1015L</translation>
    </message>
    <message>
        <location filename="sequencedialog.ui" line="312"/>
        <source>CMPS2131</source>
        <translation type="unfinished">CMPS2131</translation>
    </message>
    <message>
        <location filename="sequencedialog.ui" line="317"/>
        <source>CMPS2111</source>
        <translation type="unfinished">CMPS2111</translation>
    </message>
    <message>
        <location filename="sequencedialog.ui" line="322"/>
        <source>CMPS2151</source>
        <translation type="unfinished">CMPS2151</translation>
    </message>
    <message>
        <location filename="sequencedialog.ui" line="327"/>
        <source>CMPS2242</source>
        <translation type="unfinished">CMPS2242</translation>
    </message>
    <message>
        <location filename="sequencedialog.ui" line="332"/>
        <source>ENGL1035</source>
        <translation type="unfinished">ENGL1035</translation>
    </message>
    <message>
        <location filename="sequencedialog.ui" line="337"/>
        <source>MATH2201</source>
        <translation type="unfinished">MATH2201</translation>
    </message>
    <message>
        <location filename="sequencedialog.ui" line="342"/>
        <source>CMPS2212</source>
        <translation type="unfinished">agregar2212</translation>
    </message>
    <message>
        <location filename="sequencedialog.ui" line="347"/>
        <source>CMPS2232</source>
        <translation type="unfinished">CMPS2232</translation>
    </message>
    <message>
        <location filename="sequencedialog.ui" line="352"/>
        <source>MGMT1014</source>
        <translation type="unfinished">MGMT1014</translation>
    </message>
    <message>
        <location filename="sequencedialog.ui" line="357"/>
        <source>PSYC1014</source>
        <translation type="unfinished">PSUC1014</translation>
    </message>
    <message>
        <location filename="sequencedialog.ui" line="362"/>
        <source>HIST1014</source>
        <translation type="unfinished">HIST1014</translation>
    </message>
    <message>
        <location filename="sequencedialog.ui" line="367"/>
        <source>CMPS1192</source>
        <translation type="unfinished">CMPS1192</translation>
    </message>
    <message>
        <location filename="sequencedialog.ui" line="372"/>
        <source>CMPS2992</source>
        <translation type="unfinished">CMPS2992</translation>
    </message>
    <message>
        <location filename="sequencedialog.ui" line="377"/>
        <source>SOCL1014</source>
        <translation type="unfinished">SOCL1014</translation>
    </message>
    <message>
        <location filename="sequencedialog.ui" line="382"/>
        <source>SPAN1025</source>
        <translation type="unfinished">SPAN1025</translation>
    </message>
    <message>
        <location filename="sequencedialog.ui" line="387"/>
        <source>ECON1014</source>
        <translation type="unfinished">ECON1014</translation>
    </message>
    <message>
        <location filename="sequencedialog.ui" line="427"/>
        <source>               Sequence Management System - Sequence Information</source>
        <translation type="unfinished">Sistema de gestión de secuencias: información de secuencias</translation>
    </message>
</context>
<context>
    <name>StudentScreen</name>
    <message>
        <location filename="studentscreen.ui" line="26"/>
        <source>StudentScreen</source>
        <translation type="unfinished">pantalla de estudiante</translation>
    </message>
    <message>
        <location filename="studentscreen.ui" line="44"/>
        <source>Log out</source>
        <translation type="unfinished">cerrar sesión</translation>
    </message>
    <message>
        <location filename="studentscreen.ui" line="78"/>
        <source>                                          Sequence Management System - Student Menu</source>
        <translation type="unfinished">Sistema de gestión de secuencias - Menú del estudiante</translation>
    </message>
    <message>
        <location filename="studentscreen.ui" line="97"/>
        <source>Add Data</source>
        <translation type="unfinished">agregar datos</translation>
    </message>
    <message>
        <location filename="studentscreen.ui" line="107"/>
        <source>View Course Sequence</source>
        <translation type="unfinished">ver la secuencia del curso</translation>
    </message>
</context>
<context>
    <name>Studentdialog</name>
    <message>
        <location filename="studentdialog.ui" line="26"/>
        <source>Studentdialog</source>
        <translation type="unfinished">diálogo del estudiante</translation>
    </message>
    <message>
        <location filename="studentdialog.ui" line="47"/>
        <source>Ok</source>
        <translation type="unfinished">Ok</translation>
    </message>
    <message>
        <location filename="studentdialog.ui" line="57"/>
        <source>Cancel</source>
        <translation type="unfinished">cancelar</translation>
    </message>
    <message>
        <location filename="studentdialog.ui" line="78"/>
        <source>Student ID</source>
        <translation type="unfinished">Identificación del Estudiante</translation>
    </message>
    <message>
        <location filename="studentdialog.ui" line="112"/>
        <source>First Name</source>
        <translation type="unfinished">primer nombre</translation>
    </message>
    <message>
        <location filename="studentdialog.ui" line="146"/>
        <source>Last Name</source>
        <translation type="unfinished">apellido</translation>
    </message>
    <message>
        <location filename="studentdialog.ui" line="180"/>
        <source>Password</source>
        <translation type="unfinished">contraseña</translation>
    </message>
    <message>
        <location filename="studentdialog.ui" line="211"/>
        <source>Email</source>
        <translation type="unfinished">correo electrónico</translation>
    </message>
    <message>
        <location filename="studentdialog.ui" line="245"/>
        <source>Phone</source>
        <translation type="unfinished">teléfono</translation>
    </message>
    <message>
        <location filename="studentdialog.ui" line="279"/>
        <source>Birth Date</source>
        <translation type="unfinished">fecha de nacimiento</translation>
    </message>
    <message>
        <location filename="studentdialog.ui" line="313"/>
        <source>Gender</source>
        <translation type="unfinished">género</translation>
    </message>
    <message>
        <location filename="studentdialog.ui" line="372"/>
        <source>               Sequence Management System - Student Information</source>
        <translation type="unfinished">Sistema de gestión de secuencias : información del estudiante</translation>
    </message>
</context>
<context>
    <name>admin</name>
    <message>
        <location filename="admin.ui" line="26"/>
        <source>admin</source>
        <translation type="unfinished">administración</translation>
    </message>
    <message>
        <location filename="admin.ui" line="45"/>
        <source>Log Out</source>
        <translation type="unfinished">cerrar sesión</translation>
    </message>
    <message>
        <location filename="admin.ui" line="64"/>
        <source>Add a new Student</source>
        <translation type="unfinished">agregar un nuevo estudiante</translation>
    </message>
    <message>
        <location filename="admin.ui" line="74"/>
        <source>Add a new Lecturer</source>
        <translation type="unfinished">Añadir un(a) nueva(o) profesor(a)</translation>
    </message>
    <message>
        <location filename="admin.ui" line="84"/>
        <source>Add a new Course</source>
        <translation type="unfinished">agregar un nuevo curso</translation>
    </message>
    <message>
        <location filename="admin.ui" line="94"/>
        <source>Add a new Sequence</source>
        <translation type="unfinished">agregar una nueva secuencia</translation>
    </message>
    <message>
        <location filename="admin.ui" line="131"/>
        <source>                                         Sequence Management System - Administrator Menu</source>
        <translation type="unfinished">Sistema de gestión de secuencias: menú del administrador</translation>
    </message>
    <message>
        <location filename="admin.ui" line="146"/>
        <source>Search</source>
        <translation type="unfinished">Buscar</translation>
    </message>
    <message>
        <location filename="admin.ui" line="154"/>
        <source>toolBar</source>
        <translation type="unfinished">barra de herramientas</translation>
    </message>
    <message>
        <location filename="admin.ui" line="174"/>
        <source>Search For Student</source>
        <translation type="unfinished">buscar estudiante</translation>
    </message>
</context>
</TS>
